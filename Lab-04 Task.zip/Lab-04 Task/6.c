#include<stdio.h>
int main(){
    int o_amount, m_status, c_status;
    printf("Enter your order amount : \n");
    scanf("%d", &o_amount);
    printf("Enter '0' if you have the memebership otherwise enter '1' if you don't have the membership or expired :\n");
    scanf("%d", &m_status);
    printf("Enter if you are in city limit ('1' for within city and '0' for outside) :\n");
    scanf("%d",&c_status);
    if(o_amount > 3000 || m_status == 0){
        printf("Delivery is free for you!\n");
    }
    else{
        printf("Delivery charges apply\n");
    }
    if(o_amount < 50000 && c_status == 1){
        printf("You can use the option Delivery on cash (COD) \n");
    }
    else{
        printf("COD is not available for your order\n");
    }
    return 0;
}