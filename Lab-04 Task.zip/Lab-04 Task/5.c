#include<stdio.h>
int main(){
    float g_point;
    int c_chr,p_status;
    printf("Enter whether you passed your Programming Fundemantals or not (1 for passed and 0 for not passed) : \n");
    scanf("%d",&p_status);
    printf("Enter your grade point : \n");
    scanf("%f",&g_point);
    printf("Enter your total credit hours : \n");
    scanf("%d",&c_chr);
    if(p_status == 1 && g_point >= 2.5 && c_chr >=30){
        printf("You can register yourself for the course\n");
    }
    else{
        printf("You are not eligible to register for the course");
    }
    return 0;
}