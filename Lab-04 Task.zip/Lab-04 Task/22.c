#include <stdio.h>

int main()
{
    int plan, minutes;
    float bill = 0;

    printf("Enter plan (1-4): \n");
    scanf("%d", &plan);

    printf("Enter minutes used: \n");
    scanf("%d", &minutes);

    switch (plan)
    {
    case 1:
        bill = 500;
        if (minutes > 1000)
        {
            bill = bill + (minutes - 1000) * 2;
        }
        break;

    case 2:
        bill = 800;
        if (minutes > 2000)
        {
            bill = bill + (minutes - 2000) * 2;
        }
        break;

    case 3:
        bill = 1200;
        break;

    case 4:
        bill = minutes * 1;
        break;

    default:
        printf("Invalid plan selected.\n");
    }

    if (plan >= 1 && plan <= 4)
    {
        printf("Total Bill: Rs. %.2f\n", bill);
    }

    return 0;
}