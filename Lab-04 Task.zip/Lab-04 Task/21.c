#include <stdio.h>
int main()
{
    float temperature, pressure;

    printf("Enter temperature (C): \n");
    scanf("%f", &temperature);

    printf("Enter pressure (PSI): \n");
    scanf("%f", &pressure);

    if (temperature > 100 || pressure > 250)
    {
        printf("Status: SHUTDOWN\n");
    }
    else if (temperature >= 85 && temperature <= 100 && pressure >= 200 && pressure <= 250)
    {
        printf("Status: WARNING MODE\n");
    }
    else
    {
        printf("Status: NORMAL OPERATION\n");
    }

    return 0;
}