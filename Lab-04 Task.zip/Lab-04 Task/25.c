#include <stdio.h>

int main() {
    int zone;
    float speed, limit, fine, base_fine = 1000;

    printf("Enter zone type (1=School, 2=Highway, 3=Residential): \n");
    scanf("%d", &zone);

    printf("Enter driver's speed (km/h): \n");
    scanf("%f", &speed);

    switch (zone) {
        case 1:
            limit = 30;
            break;
        case 2:
            limit = 100;
            break;
        case 3:
            limit = 50;
            break;
        default:
            printf("Invalid zone type.\n");
            limit = -1;
    }

    if (limit != -1) {
        if (speed > limit) {
            fine = base_fine;
            if (speed - limit > 20) {
                fine = fine * 2;
            }
            printf("Fine Amount: Rs. %.2f\n", fine);
        }
        else {
            printf("No violation. No fine.\n");
        }
    }

    return 0;
}