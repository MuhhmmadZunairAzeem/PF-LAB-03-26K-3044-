#include <stdio.h>

int main() {
    int people;
    float weight;

    printf("Enter number of people: \n");
    scanf("%d", &people);

    printf("Enter total combined weight (kg): \n");
    scanf("%f", &weight);

    if (weight > 1000 && people > 10) {
        printf("Status: DENY ENTRY - Overweight AND People Limit Exceeded\n");
    }
    else if (weight > 1000) {
        printf("Status: DENY ENTRY - Overweight\n");
    }
    else if (people > 10) {
        printf("Status: DENY ENTRY - People Limit Exceeded\n");
    }
    else {
        printf("Status: NORMAL OPERATION\n");
    }

    return 0;
}